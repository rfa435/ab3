<!DOCTYPE html>
<html>
  <head>
    <title>AWS Tech Fundamentals Bootcamp</title>
    <link href="style.css" media="all" rel="stylesheet" type="text/css" />
  </head>

  <body>
    <div id="wrapper">

      <?php 
        include 'menu.php';

        $connect = mysqli_connect($RDS_URL, $RDS_user, $RDS_pwd, $RDS_DB) or die(mysqli_connect_error());

        include 'rds-read-data.php';

        include 'rds-initialize.php';
      ?>

    </div>
  </body>
</html>
