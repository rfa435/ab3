<form name="input" action="rds-write-config.php" method="post">
<input type="submit" value="Load Initial Data" />
</form>
